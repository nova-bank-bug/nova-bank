# Nova Bank — hosted fictional demo

This project upgrades the browser-only prototype to a small hosted web app backed by PostgreSQL. It supports account registration, sign-in, per-user fictional balances, transaction history, simulated transfers, and sign-out.

## Important safety and scope

Nova Bank is a **fictional demonstration**, not a bank. It does not connect to payment rails, accept deposits, move real money, verify identities, or provide real financial services. Do not enter real banking credentials, real passwords, or sensitive personal information. The sample account balances and transfers are fictional.

This is an educational starter, **not audited production financial software**. Do not use it for a real financial institution or real customers. The password is hashed with Node's scrypt; sessions are stored server-side in PostgreSQL and use HTTP-only, same-site cookies. A real regulated service needs a professional security review, threat modelling, monitoring, incident response, compliance, and qualified engineering.

## What you need

- Node.js 20+
- A PostgreSQL database from a hosting provider
- A web host that supports a Node.js server (or a server you control)

## Run locally

1. Extract the ZIP.
2. In the project folder, copy `.env.example` to `.env`.
3. Set `DATABASE_URL` to your PostgreSQL connection string.
4. Set `SESSION_SECRET` to a long random secret (at least 32 characters).
5. Install and start:

   ```bash
   npm install
   npm start
   ```

6. Open `http://localhost:3000`.

The database tables are created automatically on first start.

## Deploy so accounts work across devices

1. Create a PostgreSQL database with a reputable provider.
2. Create a Node.js web service with a host that supports persistent server processes.
3. Upload this project or connect its private Git repository.
4. Set the service's environment variables:
   - `DATABASE_URL` — private PostgreSQL connection string
   - `SESSION_SECRET` — long random secret
   - `NODE_ENV` — `production`
   - `PORT` — supplied by the host (if required)
5. Deploy and open the HTTPS URL supplied by the host.

Keep the database private. Do not put database credentials or `SESSION_SECRET` in browser JavaScript, screenshots, chat messages, or a public repository. Do not disable TLS verification for a hosted database.

## Demo registration and login

Use **Create account** to register a fictional profile. Accounts are stored in the shared PostgreSQL database, so users can sign in from another device using the same deployed website. The included demo does not have a built-in universal demo login; each visitor can create their own demo account.

## Password recovery

This starter intentionally does not claim to provide email-based password recovery. A safe recovery flow needs a verified email provider, expiring one-time tokens, rate limits, and careful account-enumeration protections. For now, use a new demo account if you lose access to a test account.

## API routes

- `POST /api/register`
- `POST /api/login`
- `GET /api/me`
- `GET /api/transactions`
- `POST /api/demo-transfer`
- `POST /api/logout`
- `GET /api/health`

All money values are stored as integer kobo. Transfers are local demo ledger updates only.
